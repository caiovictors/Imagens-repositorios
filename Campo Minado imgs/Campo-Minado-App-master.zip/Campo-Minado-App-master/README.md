# 💣 App Campo Minado
Jogo de campo minado feito com React-Native, Javascript e CSS.

## ⚙ Como Executar
  * **Baixe no celular o app EXPO e no seu computador via terminal, considerando que já possui npm instalado, com** </br>
			```$npm install --global expo-cli```
  * **Clone o repositório**
  * **No terminal da pasta, execute:** </br>
  		```$npm i ```   </br>
			```$npm start ```
## 🕹 Como jogar
  * **Selecione a dificuldade na bandeirinha no canto superior esquerdo**
  * **Divirta-se**
  
## 📱 Imagens do App
<span>
	<img src="https://github.com/caiovictors/Campo-Minado-App/blob/master/Git_Imgs/20200915_204441.jpg" width="270" heigth="480">
	<img src="https://github.com/caiovictors/Campo-Minado-App/blob/master/Git_Imgs/20200915_204455.jpg" width="270" heigth="480">
	<img src="https://github.com/caiovictors/Campo-Minado-App/blob/master/Git_Imgs/20200915_204421.jpg" width="270" heigth="480">
</span>
  
  
